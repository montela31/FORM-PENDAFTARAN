﻿namespace WindowsFormsApp1
{
    partial class FORMPENDAFTARAN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FORMPENDAFTARAN));
            this.label1 = new System.Windows.Forms.Label();
            this.txtNAMA = new System.Windows.Forms.Label();
            this.txtTEMPATLAHIR = new System.Windows.Forms.Label();
            this.dtdTANGGALLAHIR = new System.Windows.Forms.Label();
            this.txtJENISKELAMIN = new System.Windows.Forms.Label();
            this.txtPROGRAMSTUDI = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fILEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nEWToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oPENToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eDITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pASTEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.FAKULTAS = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.SEMESTER = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.UNIVERSITAS = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.NOMORTELEPON = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.EMAIL = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.ALAMAT = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.NAMAAYAH = new System.Windows.Forms.Label();
            this.PEKERJAAN = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.NOHPWALI = new System.Windows.Forms.Label();
            this.PEKERJAANWALI = new System.Windows.Forms.Label();
            this.ALAMATWALI = new System.Windows.Forms.Label();
            this.NAMAWALI = new System.Windows.Forms.Label();
            this.NOHPORANGTUA = new System.Windows.Forms.Label();
            this.NAMAIBU = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(278, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "FORM PENDAFTARAN";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtNAMA
            // 
            this.txtNAMA.AutoSize = true;
            this.txtNAMA.Location = new System.Drawing.Point(51, 97);
            this.txtNAMA.Name = "txtNAMA";
            this.txtNAMA.Size = new System.Drawing.Size(46, 16);
            this.txtNAMA.TabIndex = 1;
            this.txtNAMA.Text = "NAMA";
            // 
            // txtTEMPATLAHIR
            // 
            this.txtTEMPATLAHIR.AutoSize = true;
            this.txtTEMPATLAHIR.Location = new System.Drawing.Point(51, 145);
            this.txtTEMPATLAHIR.Name = "txtTEMPATLAHIR";
            this.txtTEMPATLAHIR.Size = new System.Drawing.Size(105, 16);
            this.txtTEMPATLAHIR.TabIndex = 2;
            this.txtTEMPATLAHIR.Text = "TEMPAT LAHIR";
            // 
            // dtdTANGGALLAHIR
            // 
            this.dtdTANGGALLAHIR.AutoSize = true;
            this.dtdTANGGALLAHIR.Location = new System.Drawing.Point(51, 193);
            this.dtdTANGGALLAHIR.Name = "dtdTANGGALLAHIR";
            this.dtdTANGGALLAHIR.Size = new System.Drawing.Size(113, 16);
            this.dtdTANGGALLAHIR.TabIndex = 3;
            this.dtdTANGGALLAHIR.Text = "TANGGAL LAHIR";
            // 
            // txtJENISKELAMIN
            // 
            this.txtJENISKELAMIN.AutoSize = true;
            this.txtJENISKELAMIN.Location = new System.Drawing.Point(51, 241);
            this.txtJENISKELAMIN.Name = "txtJENISKELAMIN";
            this.txtJENISKELAMIN.Size = new System.Drawing.Size(105, 16);
            this.txtJENISKELAMIN.TabIndex = 4;
            this.txtJENISKELAMIN.Text = "JENIS KELAMIN";
            // 
            // txtPROGRAMSTUDI
            // 
            this.txtPROGRAMSTUDI.AutoSize = true;
            this.txtPROGRAMSTUDI.Location = new System.Drawing.Point(51, 286);
            this.txtPROGRAMSTUDI.Name = "txtPROGRAMSTUDI";
            this.txtPROGRAMSTUDI.Size = new System.Drawing.Size(120, 16);
            this.txtPROGRAMSTUDI.TabIndex = 5;
            this.txtPROGRAMSTUDI.Text = "PROGRAM STUDI";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(197, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(10, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = ":";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(197, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(10, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = ":";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(197, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = ":";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(197, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(10, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = ":";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(197, 283);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(10, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = ":";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(248, 91);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(329, 22);
            this.textBox1.TabIndex = 11;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(248, 139);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(329, 22);
            this.textBox2.TabIndex = 12;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(248, 187);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 13;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(248, 237);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(86, 20);
            this.radioButton1.TabIndex = 14;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "LAKI-LAKI";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(371, 237);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(114, 20);
            this.radioButton2.TabIndex = 15;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "PEREMPUAN";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "INFORMATIKA",
            "SISTEM INFORMASI",
            "TEKNOLOGI INFORMASI"});
            this.comboBox1.Location = new System.Drawing.Point(248, 275);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 16;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fILEToolStripMenuItem,
            this.eDITToolStripMenuItem,
            this.vIEWToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(949, 28);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fILEToolStripMenuItem
            // 
            this.fILEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nEWToolStripMenuItem,
            this.oPENToolStripMenuItem,
            this.eXITToolStripMenuItem});
            this.fILEToolStripMenuItem.Name = "fILEToolStripMenuItem";
            this.fILEToolStripMenuItem.Size = new System.Drawing.Size(49, 24);
            this.fILEToolStripMenuItem.Text = "FILE";
            // 
            // nEWToolStripMenuItem
            // 
            this.nEWToolStripMenuItem.Name = "nEWToolStripMenuItem";
            this.nEWToolStripMenuItem.Size = new System.Drawing.Size(130, 26);
            this.nEWToolStripMenuItem.Text = "NEW";
            // 
            // oPENToolStripMenuItem
            // 
            this.oPENToolStripMenuItem.Name = "oPENToolStripMenuItem";
            this.oPENToolStripMenuItem.Size = new System.Drawing.Size(130, 26);
            this.oPENToolStripMenuItem.Text = "OPEN";
            // 
            // eXITToolStripMenuItem
            // 
            this.eXITToolStripMenuItem.Name = "eXITToolStripMenuItem";
            this.eXITToolStripMenuItem.Size = new System.Drawing.Size(130, 26);
            this.eXITToolStripMenuItem.Text = "EXIT";
            // 
            // eDITToolStripMenuItem
            // 
            this.eDITToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pASTEToolStripMenuItem});
            this.eDITToolStripMenuItem.Name = "eDITToolStripMenuItem";
            this.eDITToolStripMenuItem.Size = new System.Drawing.Size(54, 24);
            this.eDITToolStripMenuItem.Text = "EDIT";
            // 
            // pASTEToolStripMenuItem
            // 
            this.pASTEToolStripMenuItem.Name = "pASTEToolStripMenuItem";
            this.pASTEToolStripMenuItem.Size = new System.Drawing.Size(133, 26);
            this.pASTEToolStripMenuItem.Text = "PASTE";
            // 
            // vIEWToolStripMenuItem
            // 
            this.vIEWToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nToolStripMenuItem});
            this.vIEWToolStripMenuItem.Name = "vIEWToolStripMenuItem";
            this.vIEWToolStripMenuItem.Size = new System.Drawing.Size(58, 24);
            this.vIEWToolStripMenuItem.Text = "VIEW";
            // 
            // nToolStripMenuItem
            // 
            this.nToolStripMenuItem.Name = "nToolStripMenuItem";
            this.nToolStripMenuItem.Size = new System.Drawing.Size(125, 26);
            this.nToolStripMenuItem.Text = "NEW";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(699, 66);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(109, 114);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FAKULTAS
            // 
            this.FAKULTAS.AutoSize = true;
            this.FAKULTAS.Location = new System.Drawing.Point(51, 330);
            this.FAKULTAS.Name = "FAKULTAS";
            this.FAKULTAS.Size = new System.Drawing.Size(76, 16);
            this.FAKULTAS.TabIndex = 19;
            this.FAKULTAS.Text = "FAKULTAS";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(197, 330);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 16);
            this.label8.TabIndex = 20;
            this.label8.Text = ":";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(248, 324);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(329, 22);
            this.textBox3.TabIndex = 21;
            // 
            // SEMESTER
            // 
            this.SEMESTER.AutoSize = true;
            this.SEMESTER.Location = new System.Drawing.Point(51, 369);
            this.SEMESTER.Name = "SEMESTER";
            this.SEMESTER.Size = new System.Drawing.Size(82, 16);
            this.SEMESTER.TabIndex = 22;
            this.SEMESTER.Text = "SEMESTER";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(197, 369);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(10, 16);
            this.label7.TabIndex = 23;
            this.label7.Text = ":";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.comboBox2.Location = new System.Drawing.Point(248, 366);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 24);
            this.comboBox2.TabIndex = 24;
            // 
            // UNIVERSITAS
            // 
            this.UNIVERSITAS.AutoSize = true;
            this.UNIVERSITAS.Location = new System.Drawing.Point(53, 413);
            this.UNIVERSITAS.Name = "UNIVERSITAS";
            this.UNIVERSITAS.Size = new System.Drawing.Size(97, 16);
            this.UNIVERSITAS.TabIndex = 25;
            this.UNIVERSITAS.Text = "UNIVERSITAS";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(197, 413);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(10, 16);
            this.label9.TabIndex = 26;
            this.label9.Text = ":";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(248, 407);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(329, 22);
            this.textBox4.TabIndex = 27;
            // 
            // NOMORTELEPON
            // 
            this.NOMORTELEPON.AutoSize = true;
            this.NOMORTELEPON.Location = new System.Drawing.Point(53, 454);
            this.NOMORTELEPON.Name = "NOMORTELEPON";
            this.NOMORTELEPON.Size = new System.Drawing.Size(124, 16);
            this.NOMORTELEPON.TabIndex = 28;
            this.NOMORTELEPON.Text = "NOMOR TELEPON";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(197, 454);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(10, 16);
            this.label10.TabIndex = 29;
            this.label10.Text = ":";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(248, 448);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(329, 22);
            this.textBox5.TabIndex = 30;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // EMAIL
            // 
            this.EMAIL.AutoSize = true;
            this.EMAIL.Location = new System.Drawing.Point(53, 495);
            this.EMAIL.Name = "EMAIL";
            this.EMAIL.Size = new System.Drawing.Size(46, 16);
            this.EMAIL.TabIndex = 31;
            this.EMAIL.Text = "EMAIL";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(197, 495);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(10, 16);
            this.label12.TabIndex = 32;
            this.label12.Text = ":";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(248, 489);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(329, 22);
            this.textBox6.TabIndex = 33;
            // 
            // ALAMAT
            // 
            this.ALAMAT.AutoSize = true;
            this.ALAMAT.Location = new System.Drawing.Point(53, 538);
            this.ALAMAT.Name = "ALAMAT";
            this.ALAMAT.Size = new System.Drawing.Size(61, 16);
            this.ALAMAT.TabIndex = 35;
            this.ALAMAT.Text = "ALAMAT";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(197, 538);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(10, 16);
            this.label11.TabIndex = 36;
            this.label11.Text = ":";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(248, 532);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(329, 22);
            this.textBox7.TabIndex = 37;
            // 
            // NAMAAYAH
            // 
            this.NAMAAYAH.AutoSize = true;
            this.NAMAAYAH.Location = new System.Drawing.Point(53, 586);
            this.NAMAAYAH.Name = "NAMAAYAH";
            this.NAMAAYAH.Size = new System.Drawing.Size(86, 16);
            this.NAMAAYAH.TabIndex = 38;
            this.NAMAAYAH.Text = "NAMA AYAH";
            this.NAMAAYAH.Click += new System.EventHandler(this.NAMAORANGTUA_Click);
            // 
            // PEKERJAAN
            // 
            this.PEKERJAAN.AutoSize = true;
            this.PEKERJAAN.Location = new System.Drawing.Point(53, 687);
            this.PEKERJAAN.Name = "PEKERJAAN";
            this.PEKERJAAN.Size = new System.Drawing.Size(87, 16);
            this.PEKERJAAN.TabIndex = 39;
            this.PEKERJAAN.Text = "PEKERJAAN";
            this.PEKERJAAN.Click += new System.EventHandler(this.label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(53, 677);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 16);
            this.label14.TabIndex = 40;
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // NOHPWALI
            // 
            this.NOHPWALI.AutoSize = true;
            this.NOHPWALI.Location = new System.Drawing.Point(51, 944);
            this.NOHPWALI.Name = "NOHPWALI";
            this.NOHPWALI.Size = new System.Drawing.Size(84, 16);
            this.NOHPWALI.TabIndex = 41;
            this.NOHPWALI.Text = "NO.HP WALI";
            // 
            // PEKERJAANWALI
            // 
            this.PEKERJAANWALI.AutoSize = true;
            this.PEKERJAANWALI.Location = new System.Drawing.Point(51, 893);
            this.PEKERJAANWALI.Name = "PEKERJAANWALI";
            this.PEKERJAANWALI.Size = new System.Drawing.Size(122, 16);
            this.PEKERJAANWALI.TabIndex = 42;
            this.PEKERJAANWALI.Text = "PEKERJAAN WALI";
            // 
            // ALAMATWALI
            // 
            this.ALAMATWALI.AutoSize = true;
            this.ALAMATWALI.Location = new System.Drawing.Point(51, 839);
            this.ALAMATWALI.Name = "ALAMATWALI";
            this.ALAMATWALI.Size = new System.Drawing.Size(96, 16);
            this.ALAMATWALI.TabIndex = 43;
            this.ALAMATWALI.Text = "ALAMAT WALI";
            this.ALAMATWALI.Click += new System.EventHandler(this.label17_Click);
            // 
            // NAMAWALI
            // 
            this.NAMAWALI.AutoSize = true;
            this.NAMAWALI.Location = new System.Drawing.Point(53, 791);
            this.NAMAWALI.Name = "NAMAWALI";
            this.NAMAWALI.Size = new System.Drawing.Size(81, 16);
            this.NAMAWALI.TabIndex = 44;
            this.NAMAWALI.Text = "NAMA WALI";
            // 
            // NOHPORANGTUA
            // 
            this.NOHPORANGTUA.AutoSize = true;
            this.NOHPORANGTUA.Location = new System.Drawing.Point(51, 737);
            this.NOHPORANGTUA.Name = "NOHPORANGTUA";
            this.NOHPORANGTUA.Size = new System.Drawing.Size(129, 16);
            this.NOHPORANGTUA.TabIndex = 45;
            this.NOHPORANGTUA.Text = "NO.HP ORANGTUA";
            this.NOHPORANGTUA.Click += new System.EventHandler(this.label19_Click);
            // 
            // NAMAIBU
            // 
            this.NAMAIBU.AutoSize = true;
            this.NAMAIBU.Location = new System.Drawing.Point(53, 635);
            this.NAMAIBU.Name = "NAMAIBU";
            this.NAMAIBU.Size = new System.Drawing.Size(71, 16);
            this.NAMAIBU.TabIndex = 46;
            this.NAMAIBU.Text = "NAMA IBU";
            this.NAMAIBU.Click += new System.EventHandler(this.label20_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(197, 687);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(10, 16);
            this.label13.TabIndex = 47;
            this.label13.Text = ":";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(197, 737);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(10, 16);
            this.label15.TabIndex = 48;
            this.label15.Text = ":";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(197, 791);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(10, 16);
            this.label16.TabIndex = 49;
            this.label16.Text = ":";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(197, 839);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(10, 16);
            this.label17.TabIndex = 50;
            this.label17.Text = ":";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(197, 893);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(10, 16);
            this.label18.TabIndex = 51;
            this.label18.Text = ":";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(197, 944);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(10, 16);
            this.label19.TabIndex = 52;
            this.label19.Text = ":";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(197, 586);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(10, 16);
            this.label20.TabIndex = 53;
            this.label20.Text = ":";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(197, 635);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(10, 16);
            this.label21.TabIndex = 54;
            this.label21.Text = ":";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(248, 833);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(329, 22);
            this.textBox8.TabIndex = 55;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(248, 580);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(329, 22);
            this.textBox9.TabIndex = 56;
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(248, 629);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(329, 22);
            this.textBox10.TabIndex = 57;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(248, 677);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(329, 22);
            this.textBox11.TabIndex = 58;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(248, 731);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(329, 22);
            this.textBox12.TabIndex = 59;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(248, 785);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(329, 22);
            this.textBox13.TabIndex = 60;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(248, 887);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(329, 22);
            this.textBox14.TabIndex = 61;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(248, 941);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(329, 22);
            this.textBox15.TabIndex = 62;
            // 
            // FORMPENDAFTARAN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 1011);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.NAMAIBU);
            this.Controls.Add(this.NOHPORANGTUA);
            this.Controls.Add(this.NAMAWALI);
            this.Controls.Add(this.ALAMATWALI);
            this.Controls.Add(this.PEKERJAANWALI);
            this.Controls.Add(this.NOHPWALI);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.PEKERJAAN);
            this.Controls.Add(this.NAMAAYAH);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.ALAMAT);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.EMAIL);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.NOMORTELEPON);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.UNIVERSITAS);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.SEMESTER);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.FAKULTAS);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtPROGRAMSTUDI);
            this.Controls.Add(this.txtJENISKELAMIN);
            this.Controls.Add(this.dtdTANGGALLAHIR);
            this.Controls.Add(this.txtTEMPATLAHIR);
            this.Controls.Add(this.txtNAMA);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FORMPENDAFTARAN";
            this.Text = "FORMPENDAFTARAN";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label txtNAMA;
        private System.Windows.Forms.Label txtTEMPATLAHIR;
        private System.Windows.Forms.Label dtdTANGGALLAHIR;
        private System.Windows.Forms.Label txtJENISKELAMIN;
        private System.Windows.Forms.Label txtPROGRAMSTUDI;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fILEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eDITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nEWToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oPENToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pASTEToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label FAKULTAS;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label SEMESTER;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label UNIVERSITAS;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label NOMORTELEPON;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label EMAIL;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label ALAMAT;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label NAMAAYAH;
        private System.Windows.Forms.Label PEKERJAAN;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label NOHPWALI;
        private System.Windows.Forms.Label PEKERJAANWALI;
        private System.Windows.Forms.Label ALAMATWALI;
        private System.Windows.Forms.Label NAMAWALI;
        private System.Windows.Forms.Label NOHPORANGTUA;
        private System.Windows.Forms.Label NAMAIBU;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
    }
}

